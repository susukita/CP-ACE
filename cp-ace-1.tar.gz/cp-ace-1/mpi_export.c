/* sample program for CP-ACE function implemented on MPI */

#include "cp_mpi.h"
#include <stdio.h>

int main(int argc, char **argv){
    double sendbuf[3]; /* send buffer */
    double recvbuf[3]; /* receive buffer */
    long sendsizes[2]; /* sizes of data sent to other processes */
    int dests[2]; /* ranks of destination processes */
    int destcount; /* number of destination processes */
    long recvsize; /* total size of receive data */
    int rank;
    int i;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    /* data and destination processes */
    if(rank == 0){
        /* rank 0 sends 1.0 and 2.0 to rank 1 and sends 3.0 to rank 2 */
        sendbuf[0] = 1.0;
        sendbuf[1] = 2.0;
        sendbuf[2] = 3.0;
        sendsizes[0] = 2 * sizeof(double);
        sendsizes[1] = 1 * sizeof(double);
        dests[0] = 1;
        dests[1] = 2;
        destcount = 2;
    }else if(rank == 1){
        /* rank 1 sends 4.0 to rank 0 */
        sendbuf[0] = 4.0;
        sendsizes[0] = 1 * sizeof(double);
        dests[0] = 0;
        destcount = 1;
    }else{
        /* rank 2 sends no data */
        destcount = 0;
    }        

    /* exchange data */
    recvsize = cp_mpi_export(sendbuf, sendsizes, dests, destcount,
                             recvbuf, sizeof recvbuf, MPI_COMM_WORLD);

    /* print receive data */
    for(i = 0; i < recvsize / sizeof(double); i ++){
        printf("rank %d received %f\n", rank, recvbuf[i]);
    }

    MPI_Finalize();
    return 0;
}
