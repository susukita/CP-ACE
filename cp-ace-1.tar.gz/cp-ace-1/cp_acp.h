#ifndef CP_ACP_EXPORT_H
#define CP_ACP_EXPORT_H

#include <unistd.h>
#include <stdint.h>
#include <stdlib.h>
#include "acp.h"

void *cp_acp_allocate(long size);
void cp_acp_free(void *buf);
long cp_acp_export(const void *sendbuf, const long *sendsizes, const int *dests, int destcount, void *recvbuf, long recvsizemax);

#endif
