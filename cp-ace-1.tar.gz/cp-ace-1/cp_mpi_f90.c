/* Fortran wrapper of CP-ACE function implemented on MPI */

#include "cp_mpi.h"

long FC_FUNC_(cp_mpi_export, CP_MPI_EXPORT)(const void *sendbuf, const long *sendsizes, const int *dests, const int *destcount, void *recvbuf, const long *recvsizemax, const MPI_Fint *comm){
	return cp_mpi_export(sendbuf, sendsizes, dests, *destcount, recvbuf, *recvsizemax, MPI_Comm_f2c(*comm));
}
