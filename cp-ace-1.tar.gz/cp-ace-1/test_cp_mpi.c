/* tests for CP-ACE function implemented on MPI */

#include "mpi.h"
#include "cp_mpi.h"
#include <assert.h>
#include <limits.h>
#include <stddef.h>
#include <stdlib.h>

static void test(void);
static void test_self_dest(void);
static void test_large_size(void);

int main(int argc, char **argv){
	MPI_Init(&argc, &argv);
	test();
	test_self_dest();
	test_large_size();
	MPI_Finalize();
	return 0;
}

static void test(void){
	int recvbuf[2];
	int size;
	int rank;
	MPI_Comm_size(MPI_COMM_WORLD, &size);
	assert(size == 3);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	if(rank == 0){
		assert(cp_mpi_export(NULL, NULL, NULL, 0, recvbuf, sizeof recvbuf, MPI_COMM_WORLD) == 2 * sizeof *recvbuf);
		assert(recvbuf[0] == 5 && recvbuf[1] == 7
		       || recvbuf[0] == 7 && recvbuf[1] == 5);
	}else if(rank == 1){
		int sendbuf[] = {5, 4, 6};
		long sendsizes[] = {1 * sizeof *sendbuf, 2 * sizeof *sendbuf};
		int dests[] = {0, 2};
		assert(cp_mpi_export(sendbuf, sendsizes, dests, 2, NULL, sizeof recvbuf, MPI_COMM_WORLD) == 0);
	}else if(rank == 2){
		int sendbuf[] = {7};
		long sendsizes[] = {1 * sizeof *sendbuf};
		int dests[] = {0};
		assert(cp_mpi_export(sendbuf, sendsizes, dests, 1, recvbuf, sizeof recvbuf, MPI_COMM_WORLD) == 2 * sizeof *recvbuf);
		assert(recvbuf[0] == 4);
		assert(recvbuf[1] == 6);
	}
}

static void test_self_dest(void){
	int recvbuf[1];
	int size;
	int rank;
	MPI_Comm_size(MPI_COMM_WORLD, &size);
	assert(size == 3);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	if(rank == 1){
		int sendbuf[] = {4};
		long sendsizes[] = {1 * sizeof *sendbuf};
		int dests[] = {1};
		assert(cp_mpi_export(sendbuf, sendsizes, dests, 1, recvbuf, sizeof recvbuf, MPI_COMM_WORLD) == 1 * sizeof *recvbuf);
		assert(recvbuf[0] == 4);
	}else if(rank == 0 || rank == 2){
		assert(cp_mpi_export(NULL, NULL, NULL, 0, recvbuf, sizeof recvbuf, MPI_COMM_WORLD) == 0);
	}
}

static void test_large_size(void){
#define LARGE_SIZE (INT_MAX + 1l)
	int size;
	int rank;
	int i;
	MPI_Comm_size(MPI_COMM_WORLD, &size);
	assert(size == 3);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	if(rank == 0){
		int *recvbuf = malloc(LARGE_SIZE);
		assert(recvbuf != NULL);
		assert(cp_mpi_export(NULL, NULL, NULL, 0, recvbuf, LARGE_SIZE, MPI_COMM_WORLD) == LARGE_SIZE);
		for(i = 0; i < LARGE_SIZE / sizeof *recvbuf; i ++){
			assert(recvbuf[i] == i);
		}
		free(recvbuf);
	}else if(rank == 1){
		int *sendbuf = malloc(LARGE_SIZE);
		long sendsizes[] = {LARGE_SIZE};
		int dests[] = {0};
		assert(sendbuf != NULL);
		for(i = 0; i < LARGE_SIZE / sizeof *sendbuf; i ++){
			sendbuf[i] = i;
		}
		assert(cp_mpi_export(sendbuf, sendsizes, dests, 1, NULL, LARGE_SIZE, MPI_COMM_WORLD) == 0);
		free(sendbuf);
	}else if(rank == 2){
		assert(cp_mpi_export(NULL, NULL, NULL, 0, NULL, LARGE_SIZE, MPI_COMM_WORLD) == 0);
	}
}
