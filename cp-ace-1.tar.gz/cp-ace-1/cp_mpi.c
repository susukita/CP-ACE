/* CP-ACE function implemented on MPI */

#include "cp_mpi.h"
#include "mpi.h"
#include <stdlib.h>
#include <limits.h>

#define COUNT_MAX INT_MAX /* max count for MPI_BYTE in MPI_Send and MPI_Recv */

static void start_sends(const void *sendbuf, const long *sendsizes, const int *dests, int destcount, MPI_Comm comm, MPI_Request *requests);
static long receive(void *recvbuf, long recvsizemax, int srccount, MPI_Comm comm);
static void wait_sends(MPI_Request *requests, int requestcount);

/* duplcate communicator not to conflict with external communications
   if data size >= MPI limit, send segmented data */

long cp_mpi_export(const void *sendbuf, const long *sendsizes, const int *dests, int destcount, void *recvbuf, long recvsizemax, MPI_Comm comm0){
	static MPI_Comm comm = MPI_COMM_NULL; /* duplicated communicator */
	int size;
	int *sent;
	int *ones;
	int srccount;
	int requestcount = 0;
	MPI_Request *requests;
	long recvsize;
	int i;
	if(comm == MPI_COMM_NULL){
		MPI_Comm_dup(comm0, &comm);
		MPI_Errhandler_set(comm, MPI_ERRORS_RETURN);
	}else{
		int result;
		MPI_Comm_compare(comm0, comm, &result);
		if(result != MPI_CONGRUENT){ /* comm0 and comm are different group */
			MPI_Comm_free(&comm);
			MPI_Comm_dup(comm0, &comm);
			MPI_Errhandler_set(comm, MPI_ERRORS_RETURN);
		}
	}
	MPI_Comm_size(comm, &size);
	sent = calloc(size, sizeof *sent);
	for(i = 0; i < destcount; i ++){
		sent[dests[i]] = 1;
		/* if data size >= MPI limit, multiple sends are needed */
		requestcount += 1 + sendsizes[i] / COUNT_MAX;
	}
	ones = malloc(size * sizeof *ones); 
	for(i = 0; i < size; i ++){
		ones[i] = 1;
	}
	MPI_Reduce_scatter(sent, &srccount, ones, MPI_INT, MPI_SUM, comm);
	free(sent);
	free(ones);
	requests = malloc(requestcount * sizeof *requests);
	start_sends(sendbuf, sendsizes, dests, destcount, comm, requests);
	recvsize = receive(recvbuf, recvsizemax, srccount, comm);
	wait_sends(requests, requestcount);
	free(requests);
	return recvsize;
}

static void start_sends(const void *sendbuf, const long *sendsizes, const int *dests, int destcount, MPI_Comm comm, MPI_Request *requests){
	long c = 0;
	int requestc = 0; 
	int i;
	for(i = 0; i < destcount; i ++){
		long c1;
		/* if data size >= MPI limit, send segmented data */
		for(c1 = 0; c1 + COUNT_MAX <= sendsizes[i]; c1 += COUNT_MAX){
			MPI_Isend((char *)sendbuf + c + c1, COUNT_MAX, MPI_BYTE, dests[i], 0, comm, &requests[requestc]);
			requestc ++;
		}
		MPI_Isend((char *)sendbuf + c + c1, sendsizes[i] - c1, MPI_BYTE, dests[i], 0, comm, &requests[requestc]);
		requestc ++;
		c += sendsizes[i];
	}
}

static long receive(void *recvbuf, long recvsizemax, int srccount, MPI_Comm comm){
	long c = 0;
	int i;
	for(i = 0; i < srccount; i ++){
		long c1 = 0;
		int count;
		/* if data size >= MPI limit, receive segmented data */
		do{
			long recvsize;
			MPI_Status status;
			if(c + c1 + COUNT_MAX < recvsizemax){
				recvsize = COUNT_MAX;
			}else if(c + c1 <= recvsizemax){
				recvsize = recvsizemax - c - c1;
			}else{
				recvsize = 0;
			}
			if(MPI_Recv((char *)recvbuf + c + c1, recvsize, MPI_BYTE, MPI_ANY_SOURCE, 0, comm, &status) != MPI_SUCCESS){
				return -1;
			}
			MPI_Get_count(&status, MPI_BYTE, &count);
			c1 += count;
		}while(count == COUNT_MAX);
		c += c1;
	}
	return c;
}

static void wait_sends(MPI_Request *requests, int requestcount){
	MPI_Status *statuses = malloc(requestcount * sizeof *statuses);
	MPI_Waitall(requestcount, requests, statuses);
	free(statuses);
}
