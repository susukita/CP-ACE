c     declarations for Fortran 77 interface to CP-ACE function
c     implemented on MPI

      INCLUDE 'mpif.h'
      EXTERNAL CP_MPI_EXPORT
      INTEGER*8 CP_MPI_EXPORT
