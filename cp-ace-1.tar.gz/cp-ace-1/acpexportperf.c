#include "cp_acp.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MEGA (1 << 20)

static double wtime(void);

int main(int argc, char **argv){
	int *sendbuf;
	int *recvbuf;
	long sendsizes[2];
	int dests[2];
	int procs;
	int rank;
	double t;
	int i;
	acp_init(&argc, &argv);
	sendbuf = cp_acp_allocate(4 * MEGA);
	recvbuf = cp_acp_allocate(4 * MEGA);
	procs = acp_procs();
	rank = acp_rank();
	dests[0] = (rank - 1 + procs) % procs;
	dests[1] = (rank + 1) % procs;
	sendsizes[0] = sendsizes[1] = 2 * MEGA;
	cp_acp_export(sendbuf, sendsizes, dests, 2, recvbuf, 4 * MEGA);
	t = wtime();
	for(i = 0; i < procs; i ++){
		cp_acp_export(sendbuf, sendsizes, dests, 2, recvbuf, 4 * MEGA);
	}
	printf("Bandwidth = %f MB/s\n", 2 * 2 * MEGA / ((wtime() - t) / procs) / 1e+6);
	cp_acp_free(sendbuf);
	cp_acp_free(recvbuf);
	acp_finalize();
	return 0;
}

static double wtime(void){
	static time_t tv_sec0 = -1;
	struct timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);
	if(tv_sec0 < 0){
		tv_sec0 = ts.tv_sec;
	}
	return ts.tv_sec - tv_sec0 + ts.tv_nsec * 1e-9;
}
