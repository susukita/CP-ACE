/* error test for CP-ACE function implemented on MPI */

#include "mpi.h"
#include "cp_mpi.h"
#include <assert.h>
#include <limits.h>
#include <stddef.h>
#include <stdlib.h>

static void test(void);

int main(int argc, char **argv){
	MPI_Init(&argc, &argv);
	test();
	return 0;
}

static void test(void){
	int recvbuf[1];
	int size;
	int rank;
	MPI_Comm_size(MPI_COMM_WORLD, &size);
	assert(size == 3);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	if(rank == 0){
		assert(cp_mpi_export(NULL, NULL, NULL, 0, recvbuf, sizeof recvbuf, MPI_COMM_WORLD) < 0);
	}else if(rank == 1){
		int sendbuf[] = {5, 4};
		long sendsizes[] = {2 * sizeof *sendbuf};
		int dests[] = {0};
		assert(cp_mpi_export(sendbuf, sendsizes, dests, 1, recvbuf, sizeof recvbuf, MPI_COMM_WORLD) == 0);
	}else if(rank == 2){
		assert(cp_mpi_export(NULL, NULL, NULL, 0, recvbuf, sizeof recvbuf, MPI_COMM_WORLD) == 0);
	}
}
