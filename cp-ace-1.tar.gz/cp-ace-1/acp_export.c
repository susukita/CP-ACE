/* sample program for CP-ACE functions implemented on ACP */

#include "cp_acp.h"
#include <stdio.h>

int main(int argc, char **argv){
    double *sendbuf; /* send buffer */
    double *recvbuf; /* receive buffer */
    long sendsizes[2]; /* sizes of data sent to other processes */
    int dests[2]; /* ranks of destination processes */
    int destcount; /* number of destination processes */
    long recvsize; /* total size of receive data */
    int rank;
    int i;

    acp_init(&argc, &argv);
    rank = acp_rank();

    /* allocate send and receive buffers */
    sendbuf = cp_acp_allocate(3 * sizeof(double));
    recvbuf = cp_acp_allocate(3 * sizeof(double));

    /* data and destination processes */
    if(rank == 0){
        /* rank 0 sends 1.0 and 2.0 to rank 1 and sends 3.0 to rank 2 */
        sendbuf[0] = 1.0;
        sendbuf[1] = 2.0;
        sendbuf[2] = 3.0;
        sendsizes[0] = 2 * sizeof(double);
        sendsizes[1] = 1 * sizeof(double);
        dests[0] = 1;
        dests[1] = 2;
        destcount = 2;
    }else if(rank == 1){
        /* rank 1 sends 4.0 to rank 0 */
        sendbuf[0] = 4.0;
        sendsizes[0] = 1 * sizeof(double);
        dests[0] = 0;
        destcount = 1;
    }else{
        /* rank 2 sends no data */
        destcount = 0;
    }        

    /* exchange data */
    recvsize = cp_acp_export(sendbuf, sendsizes, dests, destcount,
                             recvbuf, 3 * sizeof(double));

    /* print receive data */
    for(i = 0; i < recvsize / sizeof(double); i ++){
        printf("rank %d received %f\n", rank, recvbuf[i]);
    }

    acp_finalize();
    return 0;
}
