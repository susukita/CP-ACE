/* tests for CP-ACE function implemented on ACP */

#include <unistd.h>
#include <stdint.h>
#include <stdlib.h>
#include "acp.h"
#include "cp_acp.h"
#include <assert.h>

#define STARTER_RESERVED_SIZE 10240

static void test(void);
static void test_zero_sendsize(void);
static void test_self_dest(void);
static void test_recvmaxsize(void);

int main(int argc, char **argv){
	acp_init(&argc, &argv);
	test();
	test_zero_sendsize();
	test_self_dest();
	test_recvmaxsize();
	acp_finalize();
	return 0;
}

static void test(void){
	int *sendbuf = cp_acp_allocate(3 * sizeof *sendbuf);
	int *recvbuf = cp_acp_allocate(2 * sizeof *recvbuf);
	int rank = acp_rank();
	long starter_memsize = atol(getenv("ACP_STARTER_MEMSIZE"));
	assert(acp_procs() == 3);
	assert(starter_memsize >= STARTER_RESERVED_SIZE + 5 * sizeof(int));
	if(rank == 0){
		assert(cp_acp_export(NULL, NULL, NULL, 0, recvbuf, 2 * sizeof *recvbuf) == 2 * sizeof *recvbuf);
		assert(recvbuf[0] == 5 && recvbuf[1] == 7
		       || recvbuf[0] == 7 && recvbuf[1] == 5);
	}else if(rank == 1){
		long sendsizes[] = {1 * sizeof *sendbuf, 2 * sizeof *sendbuf};
		int dests[] = {0, 2};
		sendbuf[0] = 5;
		sendbuf[1] = 4;
		sendbuf[2] = 6;
		assert(cp_acp_export(sendbuf, sendsizes, dests, 2, recvbuf, 2 * sizeof *recvbuf) == 0);
	}else if(rank == 2){
		long sendsizes[] = {1 * sizeof *sendbuf};
		int dests[] = {0};
		sendbuf[0] = 7;
		assert(cp_acp_export(sendbuf, sendsizes, dests, 1, recvbuf, 2 * sizeof *recvbuf) == 2 * sizeof *recvbuf);
		assert(recvbuf[0] == 4);
		assert(recvbuf[1] == 6);
	}
	cp_acp_free(sendbuf);
	cp_acp_free(recvbuf);
}

static void test_zero_sendsize(void){
	int *sendbuf = cp_acp_allocate(1 * sizeof *sendbuf);
	int *recvbuf = cp_acp_allocate(1 * sizeof *recvbuf);
	int rank = acp_rank();
	long starter_memsize = atol(getenv("ACP_STARTER_MEMSIZE"));
	assert(acp_procs() == 3);
	assert(starter_memsize >= STARTER_RESERVED_SIZE + 2 * sizeof(int));
	if(rank == 0){
		long sendsizes[] = {0, 1 * sizeof *sendbuf};
		int dests[] = {1, 2};
		sendbuf[0] = 4;
		assert(cp_acp_export(sendbuf, sendsizes, dests, 2, recvbuf, 1 * sizeof *recvbuf) == 0);
	}else if(rank == 1){
		assert(cp_acp_export(NULL, NULL, NULL, 0, recvbuf, 1 * sizeof *recvbuf) == 0);
	}else if(rank == 2){
		assert(cp_acp_export(NULL, NULL, NULL, 0, recvbuf, 1 * sizeof *recvbuf) == 1 * sizeof *recvbuf);
		assert(recvbuf[0] == 4);
	}
	cp_acp_free(sendbuf);
	cp_acp_free(recvbuf);
}

static void test_self_dest(void){
	int *sendbuf = cp_acp_allocate(1 * sizeof *sendbuf);
	int *recvbuf = cp_acp_allocate(1 * sizeof *recvbuf);
	int rank = acp_rank();
	long starter_memsize = atol(getenv("ACP_STARTER_MEMSIZE"));
	assert(acp_procs() == 3);
	assert(starter_memsize >= STARTER_RESERVED_SIZE + 2 * sizeof(int));
	if(rank == 0){
		long sendsizes[] = {1 * sizeof *sendbuf};
		int dests[] = {0};
		sendbuf[0] = 4;
		assert(cp_acp_export(sendbuf, sendsizes, dests, 1, recvbuf, 1 * sizeof *recvbuf) == 1 * sizeof *recvbuf);
		assert(recvbuf[0] == 4);
	}else if(rank == 1 || rank == 2){
		assert(cp_acp_export(NULL, NULL, NULL, 0, recvbuf, 1 * sizeof *recvbuf) == 0);
	}
	cp_acp_free(sendbuf);
	cp_acp_free(recvbuf);
}

static void test_recvmaxsize(void){
	int *sendbuf = cp_acp_allocate(1 * sizeof *sendbuf);
	int *recvbuf = cp_acp_allocate(1 * sizeof *recvbuf);
	int rank = acp_rank();
	long starter_memsize = atol(getenv("ACP_STARTER_MEMSIZE"));
	assert(acp_procs() == 3);
	assert(starter_memsize >= STARTER_RESERVED_SIZE + 2 * sizeof(int));
	if(rank == 0){
		assert(cp_acp_export(NULL, NULL, NULL, 0, recvbuf, 1 * sizeof *recvbuf) < 0);
	}else if(rank == 1){
		long sendsizes[] = {2 * sizeof *sendbuf};
		int dests[] = {0};
		sendbuf[0] = 5;
		sendbuf[1] = 4;
		assert(cp_acp_export(sendbuf, sendsizes, dests, 1, recvbuf, 1 * sizeof *recvbuf) == 0);
	}else if(rank == 2){
		assert(cp_acp_export(NULL, NULL, NULL, 0, recvbuf, 1 * sizeof *recvbuf) == 0);
	}
	cp_acp_free(sendbuf);
	cp_acp_free(recvbuf);
}
