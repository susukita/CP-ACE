#include "cp_mpi.h"
#include <stdio.h>
#include <stdlib.h>

#define MEGA (1 << 20)

int main(int argc, char **argv){
	int *sendbuf = malloc(4 * MEGA);
	int *recvbuf = malloc(4 * MEGA);
	long sendsizes[2];
	int dests[2];
	int size;
	int rank;
	double t;
	int i;
	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &size);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	dests[0] = (rank - 1 + size) % size;
	dests[1] = (rank + 1) % size;
	sendsizes[0] = sendsizes[1] = 2 * MEGA;
	cp_mpi_export(sendbuf, sendsizes, dests, 2, recvbuf, 4 * MEGA, MPI_COMM_WORLD);
	t = MPI_Wtime();
	for(i = 0; i < size; i ++){
		cp_mpi_export(sendbuf, sendsizes, dests, 2, recvbuf, 4 * MEGA, MPI_COMM_WORLD);
	}
	printf("Bandwidth = %f MB/s\n", 2 * 2 * MEGA / ((MPI_Wtime() - t) / size) / 1e+6);
	free(sendbuf);
	free(recvbuf);
	MPI_Finalize();
	return 0;
}
