/* declaration for CP-ACE function implemented on MPI */

#ifndef CP_MPI_EXPORT_H
#define CP_MPI_EXPORT_H

#include "mpi.h"

long cp_mpi_export(const void *sendbuf, const long *sendsizes, const int *dests, int destcount, void *recvbuf, long recvsizemax, MPI_Comm comm);

#endif
