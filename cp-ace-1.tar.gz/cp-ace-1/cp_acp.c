/* CP-ACE functions implemented on ACP */

#include <unistd.h>
#include <stdint.h>
#include <stdlib.h>
#include "acp.h"
#include "cp_acp.h"
#include <stddef.h>
#include <stdio.h>

#define DEFAULT_STARTER_BASE 10240
#define COLOR 0

static volatile struct work{
	long recvsize;
	void *buf;
} *work = NULL;

static long allocated_size = 0;
static int num_allocations = 0;

static volatile long *recvbufdispls = NULL;
static int destcountmax = 0;
static acp_atkey_t recvbufdisplsatkey = ACP_ATKEY_NULL;

static void reregister_receive_buffer_dispslacements(int destcountmax);
static long get_receive_buffer_displacements(const long *sendsizes, const int *dests, int destcount);
static void export(const void *sendbuf, const long *sendsizes, const int *dests, int destcount, const void *recvbuf, long recvsizemax);

/* allocate memory monotonically from head */

void *cp_acp_allocate(long size){
	void *buf;
	acp_ga_t starterga = acp_query_starter_ga(acp_rank());
	void *starter = acp_query_address(starterga);
	if(work == NULL){
		long starter_base;
		if(getenv("CP_ACP_STARTER_BASE") != NULL){
			starter_base = atol(getenv("CP_ACP_STARTER_BASE"));
		}else{
			starter_base = DEFAULT_STARTER_BASE;
		}
		work = (void *)((char *)starter + starter_base);
		work->recvsize = 0;
		acp_sync();
	}
	if(getenv("ACP_STARTER_MEMSIZE") == NULL){
		fprintf(stderr, "cp_acp_allocate: environment variable ACP_STARTER_MEMSIZE is not set\n");
		exit(EXIT_FAILURE);
	}
	/* align to sizeof(double) */
	if(size % sizeof(double) != 0){
		size += sizeof(double) - size % sizeof(double);
	}
	buf = (char *)&work->buf + allocated_size;
	if((char *)buf + size - (char *)starter > atol(getenv("ACP_STARTER_MEMSIZE"))){
		return NULL;
	}
	allocated_size += size;
	num_allocations ++;
	return buf;
}

/* Only decrement allocation counter. If cp_acp_free is called for all
   allocations, free them actually. */

void cp_acp_free(void *buf){
	num_allocations --;
	if(num_allocations == 0){
		allocated_size = 0;
	}
}

/* recvbuf has been allocated from starter memory, so GA of destination
   recvbuf is calculated from GA of destination starter memory. */
/* Once memory for destination displacements in recvbuf is registered,
   it is not unregistered. Only if larger size of memory is needed, it
   is reregistered. */

long cp_acp_export(const void *sendbuf, const long *sendsizes, const int *dests, int destcount, void *recvbuf, long recvsizemax){
	long recvsize;
	if(destcount > destcountmax){
		destcountmax = destcount;
		reregister_receive_buffer_dispslacements(destcountmax);
	}
	recvsize = get_receive_buffer_displacements(sendsizes, dests, destcount);
	export(sendbuf, sendsizes, dests, destcount, recvbuf, recvsizemax);
	if(recvsize <= recvsizemax){
		return recvsize;
	}else{
		return -1;
	}
}

static void reregister_receive_buffer_dispslacements(int destcountmax){
	if(recvbufdisplsatkey != ACP_ATKEY_NULL){
		acp_unregister_memory(recvbufdisplsatkey);
	}
	recvbufdispls = realloc((long *)recvbufdispls, destcountmax * sizeof *recvbufdispls);
	recvbufdisplsatkey = acp_register_memory((long *)recvbufdispls, destcountmax * sizeof *recvbufdispls, COLOR);
}

static long get_receive_buffer_displacements(const long *sendsizes, const int *dests, int destcount){
	acp_ga_t recvbufdisplsga = acp_query_ga(recvbufdisplsatkey, (long *)recvbufdispls);
	acp_ga_t starterga = acp_query_starter_ga(acp_rank());
	void *starter = acp_query_address(starterga);
	long recvsize;
	int i;
	for(i = 0; i < destcount; i ++){
		acp_ga_t deststarterga = acp_query_starter_ga(dests[i]);
		acp_ga_t destrecvsizega = deststarterga + ((char *)&work->recvsize - (char *)starter);
		acp_add8(recvbufdisplsga + i * sizeof *recvbufdispls, destrecvsizega, sendsizes[i], ACP_HANDLE_NULL);
	}
	acp_complete(ACP_HANDLE_ALL);
	acp_sync();
	recvsize = work->recvsize;
	work->recvsize = 0;
	return recvsize;
}

static void export(const void *sendbuf, const long *sendsizes, const int *dests, int destcount, const void *recvbuf, long recvsizemax){
	acp_ga_t starterga = acp_query_starter_ga(acp_rank());
	void *starter = acp_query_address(starterga);
	acp_ga_t sendbufga = starterga + ((char *)sendbuf - (char *)starter);
	long c = 0;
	int i;
	for(i = 0; i < destcount; i ++){
		if(recvbufdispls[i] + sendsizes[i] <= recvsizemax){
			acp_ga_t deststarterga = acp_query_starter_ga(dests[i]);
			acp_ga_t destrecvbufga = deststarterga + ((char *)recvbuf - (char *)starter);
			acp_copy(destrecvbufga + recvbufdispls[i], sendbufga + c, sendsizes[i], ACP_HANDLE_NULL);
		}
		c += sendsizes[i];
	}
	acp_complete(ACP_HANDLE_ALL);
	acp_sync();
}
